### Getting started
###### 1. Yii2 initialization
- Open cmd and run the following command into core.
- All necessary conads presents there
- `$ sh install.sh`